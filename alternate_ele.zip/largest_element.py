arr = [52, 2, 9, 11, 17]
largest = arr[0]

for num in arr:
    if num > largest:
        largest = num

print("Largest element:", largest)
1