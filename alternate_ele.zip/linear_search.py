def search(arr, N, x):

    for i in range(0, N):
        if (arr[i] == x):
            return i
    return -1