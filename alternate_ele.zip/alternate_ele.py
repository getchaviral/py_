a1=[1,2,3,4,5,6,8]
for i in range(0,len(a1),2):
    print(a1[i])

